#pragma once
/* 
 * ╔══════════════════════════════════════════════╗
 * ║  RAND — fsm.h                               ║
 * ║                                              ║
 * ║  Estados:                                    ║
 * ║    MOUSE  → BLE ativo, gyro move cursor      ║
 * ║    RECORD → captura gestos                   ║
 * ║    CONFIG → comandos USB/Python              ║
 * ║    OFF    → BLE parado                       ║
 * ║                                              ║
 * ║  Alavanca (GPIO 4 e 5, pull-up):             ║
 * ║    A=0 B=0 → MOUSE                           ║
 * ║    A=1 B=0 → RECORD                          ║
 * ║    A=0 B=1 → OFF                             ║
 * ║    A=1 B=1 → reservado                       ║
 * ║                                              ║
 * ║  CONFIG: ativado por "RAND_HELLO\n" USB      ║
 * ║          desativado por "RAND_BYE\n" USB     ║
 * ║          tem prioridade sobre a alavanca     ║
 * ╚══════════════════════════════════════════════╝
 */
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

#define FSM_SWITCH_GPIO_A   4
#define FSM_SWITCH_GPIO_B   5
#define FSM_POLL_MS         20    /* período da task em ms (~50 Hz) */

#define FSM_HELLO_STR  "RAND_HELLO"
#define FSM_BYE_STR    "RAND_BYE"

typedef enum {
    FSM_STATE_MOUSE  = 0,
    FSM_STATE_RECORD,
    FSM_STATE_CONFIG,
    FSM_STATE_OFF,
} fsm_state_t;

static const char *const FSM_STATE_NAMES[] = {
    "MOUSE","RECORD","CONFIG","OFF"
};

typedef void (*fsm_on_transition_cb_t)(fsm_state_t prev, fsm_state_t next);

esp_err_t   fsm_init(void);
void        fsm_register_transition_cb(fsm_on_transition_cb_t cb);
esp_err_t   fsm_start_task(void);
fsm_state_t fsm_get_state(void);
void        fsm_notify_serial(const char *line);

#ifdef __cplusplus
}
#endif
