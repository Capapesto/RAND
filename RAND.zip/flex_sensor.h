#pragma once
/*
 * ╔══════════════════════════════════════════════╗ 
 * ║  RAND — flex_sensor.h                       ║
 * ║                                              ║
 * ║  Lê dois sensores de flexão via ADC 12-bit.  ║
 * ║  Converte raw → resistência → curvatura.     ║
 * ║                                              ║
 * ║  Circuito (divisor de tensão):               ║
 * ║    VCC ─[R_DIV]─┬─[FLEX]─ GND               ║
 * ║                 └─ ADC PIN                   ║
 * ║                                              ║
 * ║  flex[0] → GPIO 0  (LEFT click)              ║
 * ║  flex[1] → GPIO 1  (RIGHT click)             ║
 * ╚══════════════════════════════════════════════╝
 */
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ── Hardware ───────────────────────────────── */
#define FLEX_SENSOR_COUNT    2
#define FLEX_GPIO_0          0
#define FLEX_GPIO_1          1
#define FLEX_ADC_MAX         4095
#define FLEX_VCC_MV          3300
#define FLEX_ADC_VREF_MV     3300

/* ── Parâmetros do divisor (ajuste ao seu sensor) */
#define FLEX_R_DIV_OHM       33000.0f
#define FLEX_R_FLAT_OHM      10000.0f
#define FLEX_R_BENT_OHM      50000.0f
#define FLEX_BEND_THRESHOLD  0.5f

/* ── Leitura de um sensor ───────────────────── */
typedef struct {
    uint16_t raw;         /* ADC bruto 0–4095          */
    float    resistance;  /* ohms calculados            */
    float    curvature;   /* 0.0 plano … 1.0 dobrado   */
    bool     is_bent;     /* curvatura >= threshold     */
} flex_reading_t;

/* Inicializa ADC (chamar uma vez) */
esp_err_t flex_sensor_init(void);

/* Lê um sensor (index 0 ou 1) */
esp_err_t flex_sensor_read(uint8_t index, flex_reading_t *out);

/* Lê os dois de uma vez */
esp_err_t flex_sensor_read_all(flex_reading_t out[FLEX_SENSOR_COUNT]);

/* true se AMBOS dobrados */
bool flex_sensor_both_bent(void);

/* Ajuste em runtime */
void flex_sensor_set_r_div(float r_ohm);
void flex_sensor_set_r_range(float r_flat, float r_bent);
void flex_sensor_set_threshold(float threshold);

#ifdef __cplusplus
}
#endif
