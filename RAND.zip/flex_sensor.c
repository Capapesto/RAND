/*
 * RAND — flex_sensor.c
 *c
 * Fórmulas:
 *   V_adc  = raw × V_ref / ADC_MAX
 *   R_flex = R_div × V_adc / (V_vcc - V_adc)
 *   curv   = clamp((R_flex - R_flat) / (R_bent - R_flat), 0, 1)
 */
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#include "flex_sensor.h"
#include <math.h>
#include "esp_log.h"
#include "esp_adc/adc_oneshot.h"

static const char *TAG = "FLEX";

static adc_oneshot_unit_handle_t s_adc;
static const adc_channel_t s_ch[FLEX_SENSOR_COUNT] = {
    ADC_CHANNEL_0,  /* GPIO 0 */
    ADC_CHANNEL_1,  /* GPIO 1 */
};

static float s_r_div       = FLEX_R_DIV_OHM;
static float s_r_flat      = FLEX_R_FLAT_OHM;
static float s_r_bent      = FLEX_R_BENT_OHM;
static float s_threshold   = FLEX_BEND_THRESHOLD;

/* ── Conversão interna ───────────────────────── */
static float raw_to_resistance(uint16_t raw)
{
    if (raw >= FLEX_ADC_MAX) return s_r_bent * 10.0f;
    float v = (float)raw * FLEX_ADC_VREF_MV / FLEX_ADC_MAX;
    float d = FLEX_VCC_MV - v;
    if (fabsf(d) < 1.0f) return s_r_bent * 10.0f;
    return s_r_div * v / d;
}

static float resistance_to_curvature(float r)
{
    float range = s_r_bent - s_r_flat;
    if (fabsf(range) < 1.0f) return 0.0f;
    float c = (r - s_r_flat) / range;
    if (c < 0.0f) c = 0.0f;
    if (c > 1.0f) c = 1.0f;
    return c;
}

/* ── API ─────────────────────────────────────── */
esp_err_t flex_sensor_init(void)
{
    adc_oneshot_unit_init_cfg_t uc = {
        .unit_id  = ADC_UNIT_1,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&uc, &s_adc));

    adc_oneshot_chan_cfg_t cc = {
        .atten    = ADC_ATTEN_DB_11,
        .bitwidth = ADC_BITWIDTH_12,
    };
    for (int i = 0; i < FLEX_SENSOR_COUNT; i++)
        ESP_ERROR_CHECK(adc_oneshot_config_channel(s_adc, s_ch[i], &cc));

    ESP_LOGI(TAG, "Flex sensors prontos. R_div=%.0f flat=%.0f bent=%.0f thr=%.2f",
             s_r_div, s_r_flat, s_r_bent, s_threshold);
    return ESP_OK;
}

esp_err_t flex_sensor_read(uint8_t idx, flex_reading_t *out)
{
    if (idx >= FLEX_SENSOR_COUNT || !out) return ESP_ERR_INVALID_ARG;
    int raw = 0;
    ESP_ERROR_CHECK(adc_oneshot_read(s_adc, s_ch[idx], &raw));
    out->raw        = (uint16_t)raw;
    out->resistance = raw_to_resistance(out->raw);
    out->curvature  = resistance_to_curvature(out->resistance);
    out->is_bent    = (out->curvature >= s_threshold);
    return ESP_OK;
}

esp_err_t flex_sensor_read_all(flex_reading_t out[FLEX_SENSOR_COUNT])
{
    for (uint8_t i = 0; i < FLEX_SENSOR_COUNT; i++)
        ESP_ERROR_CHECK(flex_sensor_read(i, &out[i]));
    return ESP_OK;
}

bool flex_sensor_both_bent(void)
{
    flex_reading_t r[FLEX_SENSOR_COUNT];
    if (flex_sensor_read_all(r) != ESP_OK) return false;
    return r[0].is_bent && r[1].is_bent;
}

void flex_sensor_set_r_div(float r)      { s_r_div = r; }
void flex_sensor_set_r_range(float f, float b) { s_r_flat = f; s_r_bent = b; }
void flex_sensor_set_threshold(float t)
{
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    s_threshold = t;
}
