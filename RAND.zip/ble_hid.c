/*
 * RAND — ble_hid.c
 
 * Serviços GATT registrados:
 *   0x180F  Battery Service
 *   0x1812  HID Service (mouse 5 botões)
 *   0xFF00  RAND Custom Service
 *     0xFF01  Custom Command Characteristic (notify)
 *
 * Fluxo de ble_hid_update() a cada ciclo (~50 Hz):
 *   1. mpu_get_snapshot()  → gx, gy
 *   2. gpio_get_level(9)   → scroll mode?
 *   3. flex_sensor_read_all() → LEFT / RIGHT
 *   4. gesture_read_buttons() → BACK / FORWARD
 *   5. Aplica zona morta, escala gyro
 *   6. Envia relatório HID 4 bytes
 *
 * Comandos customizados:
 *   ble_hid_send_custom_cmd("meu_comando") envia via
 *   notify na characteristic 0xFF01.
 */
#include "ble_hid.h"
#include "flex_sensor.h"
#include "gesture_engine.h"
#include "mpu6050.h"

#include <string.h>
#include <math.h>

#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

static const char *TAG = "BLE_HID";

/* ── Estado ─────────────────────────────────── */
static ble_hid_state_t   s_state       = BLE_HID_DISCONNECTED;
static uint16_t          s_conn        = BLE_HS_CONN_HANDLE_NONE;
static uint16_t          s_hid_handle;     /* HID report notify handle   */
static uint16_t          s_cmd_handle;     /* Custom cmd notify handle   */
static SemaphoreHandle_t s_mutex;
static char              s_name[32]    = "RAND Glove";
static void (*s_state_cb)(ble_hid_state_t) = NULL;

/* ════════════════════════════════════════════════
 *  HID REPORT DESCRIPTOR
 *  Mouse relativo: 5 botões + X + Y + Wheel (4 bytes)
 * ════════════════════════════════════════════════ */
static const uint8_t hid_report_map[] = {
    0x05,0x01, 0x09,0x02, 0xA1,0x01, 0x09,0x01, 0xA1,0x00,
    /* 5 botões */
    0x05,0x09, 0x19,0x01, 0x29,0x05,
    0x15,0x00, 0x25,0x01, 0x75,0x01, 0x95,0x05, 0x81,0x02,
    /* padding 3 bits */
    0x75,0x03, 0x95,0x01, 0x81,0x03,
    /* X, Y */
    0x05,0x01, 0x09,0x30, 0x09,0x31,
    0x15,0x81, 0x25,0x7F, 0x75,0x08, 0x95,0x02, 0x81,0x06,
    /* Wheel */
    0x09,0x38, 0x15,0x81, 0x25,0x7F, 0x75,0x08, 0x95,0x01, 0x81,0x06,
    0xC0, 0xC0
};

typedef struct __attribute__((packed)) {
    uint8_t buttons;
    int8_t  dx, dy, wheel;
} hid_report_t;

/* ════════════════════════════════════════════════
 *  CALLBACKS GATT
 * ════════════════════════════════════════════════ */
#define UUID16(x) BLE_UUID16_DECLARE(x)

/* UUIDs customizados (128-bit) */
static const ble_uuid128_t uuid_svc_custom =
    BLE_UUID128_INIT(0x00,0xFF,0x00,0x00,0x00,0x00,0x10,0x00,
                     0x80,0x00,0x00,0x80,0x5F,0x9B,0x34,0xFB);
static const ble_uuid128_t uuid_chr_cmd =
    BLE_UUID128_INIT(0x01,0xFF,0x00,0x00,0x00,0x00,0x10,0x00,
                     0x80,0x00,0x00,0x80,0x5F,0x9B,0x34,0xFB);

static int cb_hid_info(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ static const uint8_t i[]={0x11,0x01,0x00,0x02}; return os_mbuf_append(ctx->om,i,4)?BLE_ATT_ERR_INSUFFICIENT_RES:0; }

static int cb_report_map(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ return os_mbuf_append(ctx->om,hid_report_map,sizeof(hid_report_map))?BLE_ATT_ERR_INSUFFICIENT_RES:0; }

static int cb_hid_report(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ static const hid_report_t e={0}; return os_mbuf_append(ctx->om,&e,sizeof(e))?BLE_ATT_ERR_INSUFFICIENT_RES:0; }

static int cb_hid_ctrl(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ return 0; }

static int cb_battery(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ static const uint8_t l=80; return os_mbuf_append(ctx->om,&l,1)?BLE_ATT_ERR_INSUFFICIENT_RES:0; }

static int cb_cmd(uint16_t c,uint16_t a,struct ble_gatt_access_ctxt *ctx,void *arg)
{ return 0; /* notify only — host não lê */ }

/* ════════════════════════════════════════════════
 *  SERVIÇOS GATT
 * ════════════════════════════════════════════════ */
static const struct ble_gatt_svc_def s_svcs[] = {
    /* Battery */
    { .type=BLE_GATT_SVC_TYPE_PRIMARY, .uuid=UUID16(0x180F),
      .characteristics=(struct ble_gatt_chr_def[]){
        { .uuid=UUID16(0x2A19),.access_cb=cb_battery,.flags=BLE_GATT_CHR_F_READ|BLE_GATT_CHR_F_NOTIFY },
        {0} }},
    /* HID */
    { .type=BLE_GATT_SVC_TYPE_PRIMARY, .uuid=UUID16(0x1812),
      .characteristics=(struct ble_gatt_chr_def[]){
        { .uuid=UUID16(0x2A4A),.access_cb=cb_hid_info,   .flags=BLE_GATT_CHR_F_READ },
        { .uuid=UUID16(0x2A4B),.access_cb=cb_report_map, .flags=BLE_GATT_CHR_F_READ },
        { .uuid=UUID16(0x2A4D),.access_cb=cb_hid_report, .flags=BLE_GATT_CHR_F_READ|BLE_GATT_CHR_F_NOTIFY,
          .val_handle=&s_hid_handle },
        { .uuid=UUID16(0x2A4E),.access_cb=cb_hid_ctrl,   .flags=BLE_GATT_CHR_F_WRITE_NO_RSP },
        {0} }},
    /* RAND Custom Commands */
    { .type=BLE_GATT_SVC_TYPE_PRIMARY, .uuid=&uuid_svc_custom.u,
      .characteristics=(struct ble_gatt_chr_def[]){
        { .uuid=&uuid_chr_cmd.u, .access_cb=cb_cmd,
          .flags=BLE_GATT_CHR_F_NOTIFY, .val_handle=&s_cmd_handle },
        {0} }},
    {0}
};

/* ════════════════════════════════════════════════
 *  GAP
 * ════════════════════════════════════════════════ */
static void set_state(ble_hid_state_t ns)
{
    s_state=ns;
    if (s_state_cb) s_state_cb(ns);
}

static int gap_cb(struct ble_gap_event *ev, void *arg)
{
    switch(ev->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (ev->connect.status==0) { s_conn=ev->connect.conn_handle; set_state(BLE_HID_CONNECTED); ESP_LOGI(TAG,"Conectado."); }
        else { ble_hid_start_advertising(); }
        break;
    case BLE_GAP_EVENT_DISCONNECT:
        s_conn=BLE_HS_CONN_HANDLE_NONE; set_state(BLE_HID_DISCONNECTED);
        ESP_LOGI(TAG,"Desconectado."); ble_hid_start_advertising();
        break;
    default: break;
    }
    return 0;
}

void ble_hid_start_advertising(void)
{
    struct ble_hs_adv_fields f={
        .flags=BLE_HS_ADV_F_DISC_GEN|BLE_HS_ADV_F_BREDR_UNSUP,
        .appearance=0x03C2,.appearance_is_present=1,
        .name=(uint8_t*)s_name,.name_len=strlen(s_name),.name_is_complete=1,
    };
    struct ble_gap_adv_params p={.conn_mode=BLE_GAP_CONN_MODE_UND,.disc_mode=BLE_GAP_DISC_MODE_GEN};
    ble_gap_adv_set_fields(&f);
    ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC,NULL,BLE_HS_FOREVER,&p,gap_cb,NULL);
    set_state(BLE_HID_ADVERTISING);
    ESP_LOGI(TAG,"Advertising como \"%s\"",s_name);
}

static void on_sync(void)  { ble_hid_start_advertising(); }
static void on_reset(int r){ ESP_LOGE(TAG,"Reset:%d",r); set_state(BLE_HID_DISCONNECTED); }
static void host_task(void *a) { nimble_port_run(); nimble_port_freertos_deinit(); }

/* ════════════════════════════════════════════════
 *  UTILITÁRIOS DE ENVIO
 * ════════════════════════════════════════════════ */
static int8_t gyro_to_hid(float dps)
{
    if (fabsf(dps) < BLE_HID_GYRO_DEADZONE) return 0;
    float s = dps * BLE_HID_GYRO_SENS;
    if (s >  127.f) s =  127.f;
    if (s < -127.f) s = -127.f;
    return (int8_t)s;
}

static uint8_t apply_flex_filter(uint8_t buttons)
{
    flex_reading_t fx[FLEX_SENSOR_COUNT];
    if (flex_sensor_read_all(fx) != ESP_OK)
        return buttons & ~(RAND_BTN_LEFT|RAND_BTN_RIGHT);
    if (!fx[0].is_bent) buttons &= ~RAND_BTN_LEFT;
    if (!fx[1].is_bent) buttons &= ~RAND_BTN_RIGHT;
    return buttons;
}

static esp_err_t send_hid(int8_t dx, int8_t dy, int8_t wheel, uint8_t buttons)
{
    hid_report_t r = { .buttons=buttons&0x1F, .dx=dx, .dy=dy, .wheel=wheel };
    struct os_mbuf *om = ble_hs_mbuf_from_flat(&r,sizeof(r));
    if (!om) return ESP_ERR_NO_MEM;
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    int rc = ble_gatts_notify_custom(s_conn,s_hid_handle,om);
    xSemaphoreGive(s_mutex);
    return rc==0 ? ESP_OK : ESP_FAIL;
}

/* ════════════════════════════════════════════════
 *  API PÚBLICA
 * ════════════════════════════════════════════════ */
esp_err_t ble_hid_init(const char *device_name)
{
    if (device_name) strncpy(s_name,device_name,sizeof(s_name)-1);

    s_mutex=xSemaphoreCreateMutex();
    if (!s_mutex) return ESP_ERR_NO_MEM;

    /* GPIO scroll — pull-up, LOW = pressionado */
    gpio_config_t gc={
        .pin_bit_mask=(1ULL<<BLE_HID_SCROLL_GPIO),
        .mode=GPIO_MODE_INPUT,.pull_up_en=GPIO_PULLUP_ENABLE,
        .pull_down_en=GPIO_PULLDOWN_DISABLE,.intr_type=GPIO_INTR_DISABLE,
    };
    gpio_config(&gc);

    esp_err_t r=nvs_flash_init();
    if (r==ESP_ERR_NVS_NO_FREE_PAGES||r==ESP_ERR_NVS_NEW_VERSION_FOUND)
        { nvs_flash_erase(); r=nvs_flash_init(); }
    ESP_ERROR_CHECK(r);
    ESP_ERROR_CHECK(nimble_port_init());

    ble_hs_cfg.sync_cb=on_sync; ble_hs_cfg.reset_cb=on_reset;
    ble_hs_cfg.sm_bonding=1;
    ble_hs_cfg.sm_our_key_dist=ble_hs_cfg.sm_their_key_dist=
        BLE_SM_PAIR_KEY_DIST_ENC|BLE_SM_PAIR_KEY_DIST_ID;

    ble_svc_gap_init(); ble_svc_gatt_init();
    ESP_ERROR_CHECK(ble_gatts_count_cfg(s_svcs)==0 ? ESP_OK : ESP_FAIL);
    ESP_ERROR_CHECK(ble_gatts_add_svcs(s_svcs)==0  ? ESP_OK : ESP_FAIL);

    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG,"BLE HID iniciado. Scroll=GPIO%d",BLE_HID_SCROLL_GPIO);
    return ESP_OK;
}

/*
 * ble_hid_update() — núcleo do modo MOUSE
 *
 * Chamada a ~50 Hz pela FSM.
 * Lê MPU + scroll GPIO + flex e envia HID.
 * buttons: RAND_BTN_BACK e/ou RAND_BTN_FORWARD vindos dos GPIOs 2/3.
 */
esp_err_t ble_hid_update(uint8_t buttons)
{
    if (s_state!=BLE_HID_CONNECTED) return ESP_ERR_INVALID_STATE;

    /* 1. MPU */
    mpu_snapshot_t snap;
    if (!mpu_get_snapshot(&snap))
        return send_hid(0,0,0,apply_flex_filter(buttons));

    /* 2. Scroll button */
    bool scroll = !gpio_get_level(BLE_HID_SCROLL_GPIO);

    /* 3. Gyro → movimento */
    int8_t dx=0, dy=0, wheel=0;
    if (scroll) {
        wheel = -gyro_to_hid(snap.gy); /* inclinar pra frente = scroll up */
    } else {
        dx = gyro_to_hid(snap.gx);
        dy = gyro_to_hid(snap.gy);
    }

    /* 4. Flex → LEFT/RIGHT + botões físicos */
    flex_reading_t fx[FLEX_SENSOR_COUNT];
    flex_sensor_read_all(fx);
    if (fx[0].is_bent) buttons |= RAND_BTN_LEFT;
    if (fx[1].is_bent) buttons |= RAND_BTN_RIGHT;

    return send_hid(dx, dy, wheel, buttons);
}

esp_err_t ble_hid_send_mouse(int8_t dx, int8_t dy, int8_t wheel, uint8_t buttons)
{
    if (s_state!=BLE_HID_CONNECTED) return ESP_ERR_INVALID_STATE;
    return send_hid(dx, dy, wheel, apply_flex_filter(buttons));
}

/*
 * ble_hid_send_custom_cmd()
 * Envia string de comando via notify na characteristic 0xFF01.
 * O app Python conectado recebe e interpreta o comando.
 */
esp_err_t ble_hid_send_custom_cmd(const char *cmd)
{
    if (s_state!=BLE_HID_CONNECTED || !cmd) return ESP_ERR_INVALID_STATE;

    size_t len = strlen(cmd);
    if (len==0 || len>=32) return ESP_ERR_INVALID_ARG;

    struct os_mbuf *om = ble_hs_mbuf_from_flat(cmd, len);
    if (!om) return ESP_ERR_NO_MEM;

    xSemaphoreTake(s_mutex,portMAX_DELAY);
    int rc = ble_gatts_notify_custom(s_conn,s_cmd_handle,om);
    xSemaphoreGive(s_mutex);

    if (rc==0) ESP_LOGI(TAG,"Custom cmd enviado: \"%s\"",cmd);
    else       ESP_LOGW(TAG,"Falha ao enviar custom cmd: %d",rc);

    return rc==0 ? ESP_OK : ESP_FAIL;
}

ble_hid_state_t ble_hid_get_state(void) { return s_state; }
void ble_hid_register_state_cb(void (*cb)(ble_hid_state_t)) { s_state_cb=cb; }
