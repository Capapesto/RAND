#pragma once
/*
 * ╔══════════════════════════════════════════════╗
 *  ║  RAND — ble_hid.h                           ║
 * ║                                              ║
 * ║  Dois serviços BLE:                          ║
 * ║    1. HID over GATT (mouse 5 botões)         ║
 * ║    2. RAND Custom Service (comandos gestos)  ║
 * ║                                              ║
 * ║  Mapeamento de botões:                       ║
 * ║    flex[0] dobrado → LEFT  click             ║
 * ║    flex[1] dobrado → RIGHT click             ║
 * ║    GPIO 2          → BACK  (HID btn 4)       ║
 * ║    GPIO 3          → FWD   (HID btn 5)       ║
 * ║    GPIO 9 segurado → modo scroll             ║
 * ║                                              ║
 * ║  Movimento:                                  ║
 * ║    Normal: gx→dx, gy→dy (gyroscópio MPU)    ║
 * ║    Scroll: gy→wheel, dx=dy=0                 ║
 * ╚══════════════════════════════════════════════╝
 */
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

#define BLE_HID_GYRO_SENS      1.0f
#define BLE_HID_GYRO_DEADZONE  2.0f
#define BLE_HID_SCROLL_GPIO    9

#define RAND_BTN_LEFT      (1 << 0)
#define RAND_BTN_RIGHT     (1 << 1)
#define RAND_BTN_MIDDLE    (1 << 2)
#define RAND_BTN_BACK      (1 << 3)
#define RAND_BTN_FORWARD   (1 << 4)

typedef enum {
    BLE_HID_DISCONNECTED = 0,
    BLE_HID_ADVERTISING,
    BLE_HID_CONNECTED,
} ble_hid_state_t;

esp_err_t       ble_hid_init(const char *device_name);
void            ble_hid_start_advertising(void);
esp_err_t       ble_hid_update(uint8_t buttons);
esp_err_t       ble_hid_send_mouse(int8_t dx, int8_t dy, int8_t wheel, uint8_t buttons);
esp_err_t       ble_hid_send_custom_cmd(const char *cmd);
ble_hid_state_t ble_hid_get_state(void);
void            ble_hid_register_state_cb(void (*cb)(ble_hid_state_t));

#ifdef __cplusplus
}
#endif
