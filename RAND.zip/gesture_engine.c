/*
 * RAND — gesture_engine.c
 * 
 * Ring-buffer de GESTURE_RING_SIZE frames para gestos dinâmicos.
 * Persistência NVS: namespace "rand_gest", chave "g_XX" por gesto.
 * Botões: GPIO 2 (BACK) e GPIO 3 (FWD), pull-up, LOW = pressionado.
 */
#include "gesture_engine.h"
#include "flex_sensor.h"

#include <string.h>
#include <math.h>
#include <stdio.h>
#include <inttypes.h>

#include "esp_log.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static const char *TAG      = "GESTURE";
static const char *NVS_NS   = "rand_gest";
static const char *NVS_IDX  = "g_index";

/* ── Banco RAM ───────────────────────────────── */
static gesture_def_t     s_bank[GESTURE_MAX_COUNT];
static uint8_t           s_count    = 0;
static uint32_t          s_bitmap   = 0;
static SemaphoreHandle_t s_mutex;
static gesture_on_match_cb_t s_cb   = NULL;

/* ── Ring-buffer ─────────────────────────────── */
static gesture_frame_t s_ring[GESTURE_RING_SIZE];
static uint8_t         s_rhead  = 0;
static uint8_t         s_rcount = 0;

/* ── Estado de gravação ──────────────────────── */
typedef enum { REC_IDLE=0, REC_STATIC_PENDING, REC_DYNAMIC } rec_state_t;
static rec_state_t   s_rec    = REC_IDLE;
static gesture_def_t s_rbuf;
static uint32_t      s_rstart = 0;

/* ════════════════════════════════════════════════
 *  UTILITÁRIOS
 * ════════════════════════════════════════════════ */
static uint8_t alloc_id(void)
{
    for (uint8_t i = 0; i < GESTURE_MAX_COUNT; i++)
        if (!(s_bitmap & (1u<<i))) { s_bitmap |= (1u<<i); return i; }
    return UINT8_MAX;
}
static void free_id(uint8_t id)
{ if (id < GESTURE_MAX_COUNT) s_bitmap &= ~(1u<<id); }

static float angle_diff(float a, float b)
{
    float d = a - b;
    while (d >  180.f) d -= 360.f;
    while (d < -180.f) d += 360.f;
    return fabsf(d);
}

/* Similaridade 0–1 entre dois frames */
static float frame_sim(const gesture_frame_t *a, const gesture_frame_t *b)
{
    uint8_t tot=0, hit=0;
    tot+=2;
    if (angle_diff(a->pitch, b->pitch) <= GESTURE_TOL_ANGLE_DEG) hit++;
    if (angle_diff(a->roll,  b->roll)  <= GESTURE_TOL_ANGLE_DEG) hit++;
    tot+=2;
    if (fabsf(a->flex[0]-b->flex[0]) <= GESTURE_TOL_FLEX) hit++;
    if (fabsf(a->flex[1]-b->flex[1]) <= GESTURE_TOL_FLEX) hit++;
    tot+=1;
    if (a->buttons == b->buttons) hit++;
    return (float)hit/(float)tot;
}

/* ── Ring-buffer ─────────────────────────────── */
static void ring_push(const gesture_frame_t *f)
{
    s_ring[s_rhead] = *f;
    s_rhead = (s_rhead+1) % GESTURE_RING_SIZE;
    if (s_rcount < GESTURE_RING_SIZE) s_rcount++;
}
static const gesture_frame_t *ring_get(uint8_t idx)
{
    uint8_t p = (s_rhead - s_rcount + idx + GESTURE_RING_SIZE) % GESTURE_RING_SIZE;
    return &s_ring[p];
}

/* ════════════════════════════════════════════════
 *  NVS
 * ════════════════════════════════════════════════ */
static void nvs_key(uint8_t id, char *b, size_t l) { snprintf(b,l,"g_%02u",id); }

static void nvs_save(const gesture_def_t *g)
{
    nvs_handle_t h;
    if (nvs_open(NVS_NS, NVS_READWRITE, &h) != ESP_OK) return;
    char k[8]; nvs_key(g->id,k,sizeof(k));
    nvs_set_blob(h,k,g,sizeof(*g));
    nvs_set_u32(h,NVS_IDX,s_bitmap);
    nvs_commit(h); nvs_close(h);
}

static void nvs_erase(uint8_t id)
{
    nvs_handle_t h;
    if (nvs_open(NVS_NS, NVS_READWRITE, &h) != ESP_OK) return;
    char k[8]; nvs_key(id,k,sizeof(k));
    nvs_erase_key(h,k);
    nvs_set_u32(h,NVS_IDX,s_bitmap);
    nvs_commit(h); nvs_close(h);
}

static void nvs_load(void)
{
    nvs_handle_t h;
    if (nvs_open(NVS_NS, NVS_READONLY, &h) == ESP_ERR_NVS_NOT_FOUND) return;
    nvs_get_u32(h,NVS_IDX,&s_bitmap);
    s_count=0;
    for (uint8_t i=0;i<GESTURE_MAX_COUNT;i++) {
        if (!(s_bitmap&(1u<<i))) continue;
        char k[8]; nvs_key(i,k,sizeof(k));
        size_t sz=sizeof(gesture_def_t);
        if (nvs_get_blob(h,k,&s_bank[s_count],&sz)==ESP_OK && sz==sizeof(gesture_def_t))
            s_count++;
    }
    nvs_close(h);
    ESP_LOGI(TAG,"%u gesto(s) carregado(s) da NVS", s_count);
}

/* ════════════════════════════════════════════════
 *  RECONHECIMENTO
 * ════════════════════════════════════════════════ */
gesture_match_t gesture_recognize_static(const gesture_frame_t *frame)
{
    gesture_match_t r = {0};
    float best = 0;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++) {
        if (!s_bank[i].enabled || s_bank[i].type!=GESTURE_TYPE_STATIC) continue;
        float s = frame_sim(frame, &s_bank[i].ref_frame);
        if (s>best) { best=s; r.gesture_id=s_bank[i].id; }
    }
    xSemaphoreGive(s_mutex);
    if (best>=1.0f) {
        r.matched=true; r.confidence=best;
        if (s_cb) { gesture_def_t tmp; gesture_get_by_id(r.gesture_id,&tmp); s_cb(&tmp,best); }
    }
    return r;
}

gesture_match_t gesture_recognize_dynamic(void)
{
    gesture_match_t r = {0};
    if (s_rcount<2) return r;
    float best=0; uint8_t best_id=UINT8_MAX;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++) {
        gesture_def_t *g=&s_bank[i];
        if (!g->enabled||g->type!=GESTURE_TYPE_DYNAMIC||g->frame_count==0) continue;
        if (s_rcount<g->frame_count) continue;
        uint8_t hit=0, off=s_rcount-g->frame_count;
        for (uint8_t f=0;f<g->frame_count;f++)
            if (frame_sim(ring_get(off+f),&g->frames[f])>=GESTURE_DYNAMIC_MIN_PCT) hit++;
        float c=(float)hit/(float)g->frame_count;
        if (c>best) { best=c; best_id=g->id; }
    }
    xSemaphoreGive(s_mutex);
    if (best>=GESTURE_DYNAMIC_MIN_PCT && best_id!=UINT8_MAX) {
        r.matched=true; r.gesture_id=best_id; r.confidence=best;
        if (s_cb) { gesture_def_t tmp; gesture_get_by_id(best_id,&tmp); s_cb(&tmp,best); }
    }
    return r;
}

/* ════════════════════════════════════════════════
 *  FEED
 * ════════════════════════════════════════════════ */
void gesture_engine_feed(const gesture_frame_t *frame)
{
    ring_push(frame);
    switch (s_rec) {
    case REC_STATIC_PENDING:
        s_rbuf.ref_frame = *frame;
        s_rbuf.id = alloc_id();
        if (s_rbuf.id==UINT8_MAX) { ESP_LOGE(TAG,"Banco cheio!"); s_rec=REC_IDLE; break; }
        xSemaphoreTake(s_mutex,portMAX_DELAY);
        s_bank[s_count++]=s_rbuf;
        xSemaphoreGive(s_mutex);
        nvs_save(&s_rbuf);
        ESP_LOGI(TAG,"Estático \"%s\" [%u] salvo.", s_rbuf.name, s_rbuf.id);
        s_rec=REC_IDLE;
        break;
    case REC_DYNAMIC:
        if (s_rbuf.frame_count==0) s_rstart=frame->timestamp_ms;
        if (s_rbuf.frame_count<GESTURE_MAX_FRAMES) {
            gesture_frame_t rel=*frame;
            rel.timestamp_ms=frame->timestamp_ms-s_rstart;
            s_rbuf.frames[s_rbuf.frame_count++]=rel;
        }
        break;
    default: break;
    }
}

/* ════════════════════════════════════════════════
 *  LEITURA DE BOTÕES
 * ════════════════════════════════════════════════ */
uint8_t gesture_read_buttons(void)
{
    uint8_t m=0;
    if (!gpio_get_level(GESTURE_BTN_GPIO_BACK)) m|=GESTURE_BTN_BACK;
    if (!gpio_get_level(GESTURE_BTN_GPIO_FWD))  m|=GESTURE_BTN_FWD;
    return m;
}

/* ════════════════════════════════════════════════
 *  GRAVAÇÃO
 * ════════════════════════════════════════════════ */
esp_err_t gesture_record_static_begin(const char *name, const gesture_output_t *out)
{
    if (s_rec!=REC_IDLE||s_count>=GESTURE_MAX_COUNT) return ESP_ERR_INVALID_STATE;
    memset(&s_rbuf,0,sizeof(s_rbuf));
    strncpy(s_rbuf.name,name,GESTURE_NAME_LEN-1);
    s_rbuf.type=GESTURE_TYPE_STATIC; s_rbuf.output=*out; s_rbuf.enabled=true;
    s_rec=REC_STATIC_PENDING;
    ESP_LOGI(TAG,"Aguardando frame para \"%s\"...",name);
    return ESP_OK;
}

esp_err_t gesture_record_dynamic_begin(const char *name, const gesture_output_t *out)
{
    if (s_rec!=REC_IDLE||s_count>=GESTURE_MAX_COUNT) return ESP_ERR_INVALID_STATE;
    memset(&s_rbuf,0,sizeof(s_rbuf));
    strncpy(s_rbuf.name,name,GESTURE_NAME_LEN-1);
    s_rbuf.type=GESTURE_TYPE_DYNAMIC; s_rbuf.output=*out; s_rbuf.enabled=true;
    s_rec=REC_DYNAMIC;
    ESP_LOGI(TAG,"Gravação dinâmica \"%s\" iniciada.",name);
    return ESP_OK;
}

esp_err_t gesture_record_dynamic_end(void)
{
    if (s_rec!=REC_DYNAMIC) return ESP_ERR_INVALID_STATE;
    if (s_rbuf.frame_count<2) { s_rec=REC_IDLE; return ESP_ERR_INVALID_SIZE; }
    s_rbuf.total_duration_ms=s_rbuf.frames[s_rbuf.frame_count-1].timestamp_ms;
    s_rbuf.id=alloc_id();
    if (s_rbuf.id==UINT8_MAX) { s_rec=REC_IDLE; return ESP_ERR_NO_MEM; }
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    s_bank[s_count++]=s_rbuf;
    xSemaphoreGive(s_mutex);
    nvs_save(&s_rbuf);
    // Em vez de apenas passar as variáveis, converta-as para o tipo esperado:
    ESP_LOGI(TAG, "Dinâmico \"%s\" [%" PRIu32 "] salvo. %" PRIu32 " frames/%" PRIu32 "ms",
         s_rbuf.name, 
         (uint32_t)s_rbuf.id, 
         (uint32_t)s_rbuf.frame_count, 
         (uint32_t)s_rbuf.total_duration_ms);
            s_rec=REC_IDLE;
    return ESP_OK;
}

void gesture_record_cancel(void) { s_rec=REC_IDLE; ESP_LOGI(TAG,"Gravação cancelada."); }
bool gesture_is_recording(void)  { return s_rec!=REC_IDLE; }

/* ════════════════════════════════════════════════
 *  GERENCIAMENTO
 * ════════════════════════════════════════════════ */
esp_err_t gesture_list(gesture_def_t *list, uint8_t max, uint8_t *count)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    uint8_t n=(s_count<max)?s_count:max;
    memcpy(list,s_bank,n*sizeof(gesture_def_t));
    *count=n;
    xSemaphoreGive(s_mutex);
    return ESP_OK;
}

esp_err_t gesture_get_by_id(uint8_t id, gesture_def_t *out)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++)
        if (s_bank[i].id==id) { *out=s_bank[i]; xSemaphoreGive(s_mutex); return ESP_OK; }
    xSemaphoreGive(s_mutex);
    return ESP_ERR_NOT_FOUND;
}

esp_err_t gesture_delete(uint8_t id)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++) {
        if (s_bank[i].id==id) {
            memmove(&s_bank[i],&s_bank[i+1],(s_count-i-1)*sizeof(gesture_def_t));
            s_count--; free_id(id);
            xSemaphoreGive(s_mutex);
            nvs_erase(id);
            return ESP_OK;
        }
    }
    xSemaphoreGive(s_mutex);
    return ESP_ERR_NOT_FOUND;
}

esp_err_t gesture_set_enabled(uint8_t id, bool en)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++)
        if (s_bank[i].id==id) { s_bank[i].enabled=en; gesture_def_t t=s_bank[i]; xSemaphoreGive(s_mutex); nvs_save(&t); return ESP_OK; }
    xSemaphoreGive(s_mutex);
    return ESP_ERR_NOT_FOUND;
}

esp_err_t gesture_save_all_to_nvs(void)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    for (uint8_t i=0;i<s_count;i++) nvs_save(&s_bank[i]);
    xSemaphoreGive(s_mutex);
    return ESP_OK;
}

esp_err_t gesture_factory_reset(void)
{
    nvs_handle_t h;
    if (nvs_open(NVS_NS,NVS_READWRITE,&h)==ESP_OK) { nvs_erase_all(h); nvs_commit(h); nvs_close(h); }
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    memset(s_bank,0,sizeof(s_bank)); s_count=0; s_bitmap=0;
    xSemaphoreGive(s_mutex);
    return ESP_OK;
}

/* ════════════════════════════════════════════════
 *  INIT
 * ════════════════════════════════════════════════ */
esp_err_t gesture_engine_init(void)
{
    s_mutex=xSemaphoreCreateMutex();
    if (!s_mutex) return ESP_ERR_NO_MEM;

    gpio_config_t c={
        .pin_bit_mask=(1ULL<<GESTURE_BTN_GPIO_BACK)|(1ULL<<GESTURE_BTN_GPIO_FWD),
        .mode=GPIO_MODE_INPUT,
        .pull_up_en=GPIO_PULLUP_ENABLE,
        .pull_down_en=GPIO_PULLDOWN_DISABLE,
        .intr_type=GPIO_INTR_DISABLE,
    };
    gpio_config(&c);

    nvs_load();
    ESP_LOGI(TAG,"Gesture engine pronto. %u gestos em RAM.",s_count);
    return ESP_OK;
}

void gesture_engine_set_match_cb(gesture_on_match_cb_t cb) { s_cb=cb; }
