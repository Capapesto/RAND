/*
 * RAND — fsm.c
 * 
 * A task roda a ~50 Hz (FSM_POLL_MS = 20 ms).
 *
 * Estado MOUSE:
 *   - Lê MPU + flex + botões físicos
 *   - Monta gesture_frame_t e alimenta o gesture_engine
 *   - gesture_engine dispara o callback on_gesture_match
 *     quando reconhece algo (envia HID ou custom cmd)
 *   - Chama ble_hid_update() para enviar movimento contínuo
 *
 * Estado RECORD:
 *   - Continua alimentando o gesture_engine (ring-buffer vivo)
 *   - Gravação iniciada/encerrada via comandos USB (Python)
 *
 * Estado CONFIG:
 *   - Pausa o envio HID de movimento
 *   - Aguarda comandos do Python via USB serial
 *
 * Estado OFF:
 *   - Para o advertising BLE
 *   - Task fica em idle
 */
#include "fsm.h"
#include "ble_hid.h"
#include "gesture_engine.h"
#include "flex_sensor.h"
#include "mpu6050.h"

#include <string.h>
#include "esp_log.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

static const char *TAG = "FSM";

static volatile fsm_state_t   s_state         = FSM_STATE_MOUSE;
static volatile bool          s_config_active = false;
static SemaphoreHandle_t      s_mutex;
static fsm_on_transition_cb_t s_transition_cb = NULL;

/* ── Transição ───────────────────────────────── */
static void transition(fsm_state_t next)
{
    xSemaphoreTake(s_mutex,portMAX_DELAY);
    fsm_state_t prev = s_state;
    s_state = next;
    xSemaphoreGive(s_mutex);
    if (prev==next) return;
    ESP_LOGI(TAG,"%s → %s", FSM_STATE_NAMES[prev], FSM_STATE_NAMES[next]);
    if (s_transition_cb) s_transition_cb(prev,next);
}

/* ── Lê alavanca ─────────────────────────────── */
static fsm_state_t read_switch(void)
{
    bool a = !gpio_get_level(FSM_SWITCH_GPIO_A);
    bool b = !gpio_get_level(FSM_SWITCH_GPIO_B);
    if (!a && !b) return FSM_STATE_MOUSE;
    if ( a && !b) return FSM_STATE_RECORD;
    if (!a &&  b) return FSM_STATE_OFF;
    return s_state; /* A=1 B=1 reservado */
}

/* ── Monta frame de sensores ─────────────────── */
static void build_frame(gesture_frame_t *f)
{
    mpu_snapshot_t snap = {0};
    flex_reading_t fx[FLEX_SENSOR_COUNT];

    mpu_get_snapshot(&snap);
    flex_sensor_read_all(fx);

    f->pitch        = snap.pitch;
    f->roll         = snap.roll;
    f->flex[0]      = fx[0].curvature;
    f->flex[1]      = fx[1].curvature;
    f->buttons      = gesture_read_buttons();
    f->timestamp_ms = (uint32_t)(snap.timestamp / 1000);
}

/* ── Lógica por estado ───────────────────────── */
static void run_mouse(void)
{
    gesture_frame_t frame;
    build_frame(&frame);

    /* Alimenta engine → pode disparar callback de match */
    gesture_engine_feed(&frame);
    gesture_recognize_static(&frame);

    /* Envia HID com botões físicos (BACK/FWD) */
    /* LEFT/RIGHT são gerados internamente pelo ble_hid pelo flex */
    uint8_t btns = 0;
    if (frame.buttons & GESTURE_BTN_BACK) btns |= RAND_BTN_BACK;
    if (frame.buttons & GESTURE_BTN_FWD)  btns |= RAND_BTN_FORWARD;

    ble_hid_update(btns);
}

static void run_record(void)
{
    gesture_frame_t frame;
    build_frame(&frame);
    gesture_engine_feed(&frame);

    if (gesture_is_recording())
        ESP_LOGD(TAG,"Rec: pitch=%.1f roll=%.1f flex=[%.2f %.2f]",
                 frame.pitch, frame.roll, frame.flex[0], frame.flex[1]);
}

static void run_config(void)
{
    /* Lógica fica na task USB — FSM apenas aguarda */
    vTaskDelay(pdMS_TO_TICKS(FSM_POLL_MS));
}

static void run_off(void)
{
    vTaskDelay(pdMS_TO_TICKS(FSM_POLL_MS));
}

/* ── Task principal ──────────────────────────── */
static void fsm_task(void *arg)
{
    fsm_state_t last_sw = FSM_STATE_MOUSE;

    while (1) {
        /* CONFIG tem prioridade sobre alavanca */
        if (s_config_active) {
            if (s_state != FSM_STATE_CONFIG) transition(FSM_STATE_CONFIG);
            run_config();
            continue;
        }

        /* Lê alavanca */
        fsm_state_t sw = read_switch();
        if (sw != last_sw) {
            last_sw = sw;

            /* Cancela gravação ao sair de RECORD */
            if (s_state==FSM_STATE_RECORD && gesture_is_recording())
                gesture_record_cancel();

            /* Para BLE ao entrar em OFF */
            if (sw==FSM_STATE_OFF) ble_gap_adv_stop();

            /* Reinicia advertising ao voltar para MOUSE */
            if (sw==FSM_STATE_MOUSE && s_state==FSM_STATE_OFF)
                ble_hid_start_advertising();

            transition(sw);
        }

        switch (s_state) {
        case FSM_STATE_MOUSE:  run_mouse();  break;
        case FSM_STATE_RECORD: run_record(); break;
        case FSM_STATE_OFF:    run_off();    break;
        default: break;
        }

        vTaskDelay(pdMS_TO_TICKS(FSM_POLL_MS));
    }
}

/* ════════════════════════════════════════════════
 *  API
 * ════════════════════════════════════════════════ */
esp_err_t fsm_init(void)
{
    s_mutex = xSemaphoreCreateMutex();
    if (!s_mutex) return ESP_ERR_NO_MEM;

    gpio_config_t c = {
        .pin_bit_mask = (1ULL<<FSM_SWITCH_GPIO_A)|(1ULL<<FSM_SWITCH_GPIO_B),
        .mode=GPIO_MODE_INPUT, .pull_up_en=GPIO_PULLUP_ENABLE,
        .pull_down_en=GPIO_PULLDOWN_DISABLE, .intr_type=GPIO_INTR_DISABLE,
    };
    gpio_config(&c);

    s_state        = FSM_STATE_MOUSE;
    s_config_active = false;
    ESP_LOGI(TAG,"FSM pronta. Estado: MOUSE");
    return ESP_OK;
}

void fsm_register_transition_cb(fsm_on_transition_cb_t cb) { s_transition_cb=cb; }

esp_err_t fsm_start_task(void)
{
    return xTaskCreate(fsm_task,"fsm",4096,NULL,5,NULL)==pdPASS ? ESP_OK : ESP_FAIL;
}

fsm_state_t fsm_get_state(void) { return s_state; }

void fsm_notify_serial(const char *line)
{
    if (!line) return;
    if (strncmp(line,FSM_HELLO_STR,strlen(FSM_HELLO_STR))==0) {
        ESP_LOGI(TAG,"Python conectado → CONFIG");
        s_config_active=true;
    } else if (strncmp(line,FSM_BYE_STR,strlen(FSM_BYE_STR))==0) {
        ESP_LOGI(TAG,"Python desconectou → MOUSE");
        s_config_active=false;
        transition(FSM_STATE_MOUSE);
        if (ble_hid_get_state()==BLE_HID_DISCONNECTED)
            ble_hid_start_advertising();
    }
}
