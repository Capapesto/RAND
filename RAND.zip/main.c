/*
   ╔══════════════════════════════════════════════╗
   ║  RAND — main.c                              ║
   ║                                              ║
   ║  Sequência de boot (7 passos):               ║
   ║    1. NVS flash                              ║
   ║    2. Flex sensors (ADC GPIO 0/1)            ║
   ║    3. MPU6050 (I2C + tasks internas)         ║
   ║    4. Gesture engine (NVS → RAM)             ║
   ║    5. BLE HID + Custom Service               ║
   ║    6. USB Serial (task de comandos Python)   ║
   ║    7. FSM (task principal)                   ║
   ╚══════════════════════════════════════════════╝
*/
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/usb_serial_jtag.h"
#include "driver/gpio.h"

#include "flex_sensor.h"
#include "mpu6050.h"
#include "gesture_engine.h"
#include "ble_hid.h"
#include "fsm.h"

static const char *TAG = "RAND";

#define USB_BUF 256

/* ════════════════════════════════════════════════
    CALLBACK — GESTO RECONHECIDO

    Chamado pelo gesture_engine quando um gesto bate.
    Executa a saída mapeada: HID mouse, HID tecla
    ou comando customizado via BLE.
   ════════════════════════════════════════════════ */
static void on_gesture_match(const gesture_def_t *g, float conf)
{
  ESP_LOGI(TAG, "Gesto: \"%s\" [ID %u] %.0f%%", g->name, g->id, conf * 100.f);

  switch (g->output.type) {

    case GESTURE_OUT_HID_MOUSE:
      ble_hid_send_mouse(
        g->output.mouse.dx,
        g->output.mouse.dy,
        g->output.mouse.wheel,
        g->output.mouse.buttons
      );
      break;

    case GESTURE_OUT_HID_KEY:
      /* TODO: implementar módulo teclado HID */
      ESP_LOGI(TAG, "Tecla HID: mod=0x%02X key=0x%02X",
               g->output.key.modifier, g->output.key.keycode);
      break;

    case GESTURE_OUT_CUSTOM_CMD:
      /* Envia comando via BLE Custom Service (UUID 0xFF01) */
      ble_hid_send_custom_cmd(g->output.cmd);
      break;
  }
}

/* ════════════════════════════════════════════════
    CALLBACK — TRANSIÇÃO DA FSM
   ════════════════════════════════════════════════ */
static void on_fsm_transition(fsm_state_t prev, fsm_state_t next)
{
  ESP_LOGI(TAG, "FSM: %s → %s",
           FSM_STATE_NAMES[prev], FSM_STATE_NAMES[next]);

  /* Responde ao Python sobre mudança de estado */
  char msg[48];
  snprintf(msg, sizeof(msg), "STATE:%s\n", FSM_STATE_NAMES[next]);
  usb_serial_jtag_write_bytes((uint8_t*)msg, strlen(msg), pdMS_TO_TICKS(10));

  /*
     TODO: acionar LED RGB conforme estado:
       MOUSE  → azul pulsando
       RECORD → vermelho fixo
       CONFIG → amarelo
       OFF    → apagado
  */
}

/* ════════════════════════════════════════════════
    CALLBACK — ESTADO BLE
   ════════════════════════════════════════════════ */
static void on_ble_state(ble_hid_state_t state)
{
  const char *msgs[] = { "BLE: desconectado", "BLE: advertising...", "BLE: conectado!" };
  ESP_LOGI(TAG, "%s", msgs[state]);

  /* Notifica Python */
  char msg[32];
  snprintf(msg, sizeof(msg), "BLE:%s\n",
           state == BLE_HID_CONNECTED ? "CONNECTED" :
           state == BLE_HID_ADVERTISING ? "ADVERTISING" : "DISCONNECTED");
  usb_serial_jtag_write_bytes((uint8_t*)msg, strlen(msg), pdMS_TO_TICKS(10));
}

/* ════════════════════════════════════════════════
    PROCESSADOR DE COMANDOS USB

    Protocolo de texto simples (uma linha por comando):

    Handshake:
      RAND_HELLO          → entra em CONFIG
      RAND_BYE            → sai de CONFIG

    Gestos (só aceitos em CONFIG):
      REC_STATIC:<nome>   → inicia gravação estática
      REC_DYN_START:<nom> → inicia gravação dinâmica
      REC_DYN_END         → finaliza gravação dinâmica
      REC_CANCEL          → cancela gravação
      DEL:<id>            → deleta gesto por ID
      ENABLE:<id>         → habilita gesto
      DISABLE:<id>        → desabilita gesto
      LIST                → responde com JSON dos gestos
      FACTORY_RESET       → apaga todos os gestos

    Calibração flex (só em CONFIG):
      FLEX_THR:<0.0-1.0>  → ajusta threshold de curvatura
      FLEX_RDIV:<ohms>    → ajusta resistor do divisor
      FLEX_RANGE:<f>,<b>  → ajusta R_flat e R_bent

    Leitura ao vivo:
      GET_SENSORS         → responde com snapshot JSON
   ════════════════════════════════════════════════ */
static void process_cmd(const char *line)
{
  /* Handshake — aceito em qualquer estado */
  fsm_notify_serial(line);

  /* Demais comandos só em CONFIG */
  if (fsm_get_state() != FSM_STATE_CONFIG) return;

  /* ── Gravação de gestos ───────────────────── */
  if (strncmp(line, "REC_STATIC:", 11) == 0) {
    gesture_output_t out = { .type = GESTURE_OUT_CUSTOM_CMD };
    strncpy(out.cmd, line + 11, GESTURE_CMD_LEN - 1);
    gesture_record_static_begin(line + 11, &out);
    usb_serial_jtag_write_bytes((uint8_t*)"OK:REC_STATIC\n", 14, pdMS_TO_TICKS(10));
  }
  else if (strncmp(line, "REC_DYN_START:", 14) == 0) {
    gesture_output_t out = { .type = GESTURE_OUT_CUSTOM_CMD };
    strncpy(out.cmd, line + 14, GESTURE_CMD_LEN - 1);
    gesture_record_dynamic_begin(line + 14, &out);
    usb_serial_jtag_write_bytes((uint8_t*)"OK:REC_DYN_START\n", 17, pdMS_TO_TICKS(10));
  }
  else if (strcmp(line, "REC_DYN_END") == 0) {
    esp_err_t e = gesture_record_dynamic_end();
    const char *r = (e == ESP_OK) ? "OK:REC_DYN_END\n" : "ERR:FEW_FRAMES\n";
    usb_serial_jtag_write_bytes((uint8_t*)r, strlen(r), pdMS_TO_TICKS(10));
  }
  else if (strcmp(line, "REC_CANCEL") == 0) {
    gesture_record_cancel();
    usb_serial_jtag_write_bytes((uint8_t*)"OK:CANCELLED\n", 13, pdMS_TO_TICKS(10));
  }

  /* ── Gerenciamento ───────────────────────── */
  else if (strncmp(line, "DEL:", 4) == 0) {
    uint8_t id = (uint8_t)atoi(line + 4);
    esp_err_t e = gesture_delete(id);
    char r[32]; snprintf(r, sizeof(r), "%s:%u\n", e == ESP_OK ? "OK" : "ERR", id);
    usb_serial_jtag_write_bytes((uint8_t*)r, strlen(r), pdMS_TO_TICKS(10));
  }
  else if (strncmp(line, "ENABLE:", 7) == 0) {
    gesture_set_enabled((uint8_t)atoi(line + 7), true);
    usb_serial_jtag_write_bytes((uint8_t*)"OK\n", 3, pdMS_TO_TICKS(10));
  }
  else if (strncmp(line, "DISABLE:", 8) == 0) {
    gesture_set_enabled((uint8_t)atoi(line + 8), false);
    usb_serial_jtag_write_bytes((uint8_t*)"OK\n", 3, pdMS_TO_TICKS(10));
  }
  else if (strcmp(line, "FACTORY_RESET") == 0) {
    gesture_factory_reset();
    usb_serial_jtag_write_bytes((uint8_t*)"OK:RESET\n", 9, pdMS_TO_TICKS(10));
  }

  /* ── Listagem de gestos → JSON ───────────── */
  else if (strcmp(line, "LIST") == 0) {
    gesture_def_t list[GESTURE_MAX_COUNT];
    uint8_t count = 0;
    gesture_list(list, GESTURE_MAX_COUNT, &count);

    usb_serial_jtag_write_bytes((uint8_t*)"LIST:[", 6, pdMS_TO_TICKS(10));
    for (uint8_t i = 0; i < count; i++) {
      char buf[256];
      snprintf(buf, sizeof(buf),
               "{\"id\":%u,\"name\":\"%s\",\"type\":%u,"
               "\"enabled\":%s,\"out_type\":%u,\"cmd\":\"%s\"}%s",
               list[i].id, list[i].name, list[i].type,
               list[i].enabled ? "true" : "false",
               list[i].output.type,
               list[i].output.type == GESTURE_OUT_CUSTOM_CMD
               ? list[i].output.cmd : "",
               i < count - 1 ? "," : "");
      usb_serial_jtag_write_bytes((uint8_t*)buf, strlen(buf), pdMS_TO_TICKS(20));
    }
    usb_serial_jtag_write_bytes((uint8_t*)"]\n", 2, pdMS_TO_TICKS(10));
  }

  /* ── Calibração flex ─────────────────────── */
  else if (strncmp(line, "FLEX_THR:", 9) == 0) {
    flex_sensor_set_threshold(atof(line + 9));
    usb_serial_jtag_write_bytes((uint8_t*)"OK\n", 3, pdMS_TO_TICKS(10));
  }
  else if (strncmp(line, "FLEX_RDIV:", 10) == 0) {
    flex_sensor_set_r_div(atof(line + 10));
    usb_serial_jtag_write_bytes((uint8_t*)"OK\n", 3, pdMS_TO_TICKS(10));
  }
  else if (strncmp(line, "FLEX_RANGE:", 11) == 0) {
    float f = 0, b = 0; sscanf(line + 11, "%f,%f", &f, &b);
    flex_sensor_set_r_range(f, b);
    usb_serial_jtag_write_bytes((uint8_t*)"OK\n", 3, pdMS_TO_TICKS(10));
  }

  /* ── Snapshot ao vivo ────────────────────── */
  else if (strcmp(line, "GET_SENSORS") == 0) {
    mpu_snapshot_t snap = {0};
    flex_reading_t fx[FLEX_SENSOR_COUNT];
    mpu_get_snapshot(&snap);
    flex_sensor_read_all(fx);
    char buf[192];
    snprintf(buf, sizeof(buf),
             "SENSORS:{\"pitch\":%.2f,\"roll\":%.2f,"
             "\"gx\":%.2f,\"gy\":%.2f,"
             "\"flex0\":%.3f,\"flex1\":%.3f,"
             "\"btn_back\":%d,\"btn_fwd\":%d}\n",
             snap.pitch, snap.roll, snap.gx, snap.gy,
             fx[0].curvature, fx[1].curvature,
             !gpio_get_level(GESTURE_BTN_GPIO_BACK),
             !gpio_get_level(GESTURE_BTN_GPIO_FWD));
    usb_serial_jtag_write_bytes((uint8_t*)buf, strlen(buf), pdMS_TO_TICKS(20));
  }
}

/* ════════════════════════════════════════════════
    TASK USB SERIAL
   ════════════════════════════════════════════════ */
static void usb_task(void *arg)
{
  static char buf[USB_BUF];
  uint8_t pos = 0;

  /* Anuncia ao Python que está pronto */
  const char *ready = "RAND_READY\n";
  usb_serial_jtag_write_bytes((uint8_t*)ready, strlen(ready), pdMS_TO_TICKS(100));
  ESP_LOGI(TAG, "USB serial pronto.");

  while (1) {
    uint8_t byte;
    if (usb_serial_jtag_read_bytes(&byte, 1, pdMS_TO_TICKS(20)) <= 0) continue;

    if (byte == '\n' || byte == '\r') {
      if (pos > 0) {
        buf[pos] = '\0';
        ESP_LOGD(TAG, "USB RX: \"%s\"", buf);
        process_cmd(buf);
        pos = 0;
      }
    } else if (pos < USB_BUF - 1) {
      buf[pos++] = (char)byte;
    }
  }
}

/* ════════════════════════════════════════════════
    APP_MAIN
   ════════════════════════════════════════════════ */
void app_main(void)
{
  ESP_LOGI(TAG, "╔═══════════════════════════╗");
  ESP_LOGI(TAG, "║  RAND Glove — boot        ║");
  ESP_LOGI(TAG, "╚═══════════════════════════╝");

  /* 1. NVS */
  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
      ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_LOGW(TAG, "NVS corrompida — resetando.");
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);
  ESP_LOGI(TAG, "[1/7] NVS OK");

  /* 2. Flex sensors */
  ESP_ERROR_CHECK(flex_sensor_init());
  /* Ajuste conforme seu hardware: */
  /* flex_sensor_set_r_div(33000.f);          */
  /* flex_sensor_set_r_range(10000.f,50000.f);*/
  /* flex_sensor_set_threshold(0.5f);         */
  ESP_LOGI(TAG, "[2/7] Flex sensors OK");

  /* 3. MPU6050 */
  mpu_main();
  vTaskDelay(pdMS_TO_TICKS(150)); /* estabiliza filtro complementar */
  ESP_LOGI(TAG, "[3/7] MPU6050 OK");

  /* 4. Gesture engine */
  gesture_engine_set_match_cb(on_gesture_match);
  ESP_ERROR_CHECK(gesture_engine_init());
  ESP_LOGI(TAG, "[4/7] Gesture engine OK");

  /* 5. BLE HID */
  ble_hid_register_state_cb(on_ble_state);
  ESP_ERROR_CHECK(ble_hid_init("RAND Glove"));
  ESP_LOGI(TAG, "[5/7] BLE HID OK");

  /* 6. USB Serial */
  usb_serial_jtag_driver_config_t usb_cfg = {
    .rx_buffer_size = USB_BUF,
    .tx_buffer_size = USB_BUF,
  };
  ESP_ERROR_CHECK(usb_serial_jtag_driver_install(&usb_cfg));
  xTaskCreate(usb_task, "usb", 4096, NULL, 4, NULL);
  ESP_LOGI(TAG, "[6/7] USB serial OK");

  /* 7. FSM */
  fsm_register_transition_cb(on_fsm_transition);
  ESP_ERROR_CHECK(fsm_init());
  ESP_ERROR_CHECK(fsm_start_task());
  ESP_LOGI(TAG, "[7/7] FSM OK");

  ESP_LOGI(TAG, "Boot  completo. Aguardando BLE...");
}
// Forçando recarregament