#pragma once
/* 
 * ╔══════════════════════════════════════════════╗
 * ║  RAND — gesture_engine.h                    ║
 * ║                                              ║
 * ║  Captura, reconhece e persiste gestos.       ║
 * ║                                              ║
 * ║  Entradas por frame:                         ║
 * ║    pitch, roll   → MPU6050                   ║
 * ║    flex[2]       → curvatura norm. (0–1)     ║
 * ║    buttons       → GPIO 2 (BACK) e 3 (FWD)  ║
 * ║                                              ║
 * ║  Saídas possíveis por gesto:                 ║
 * ║    HID mouse / HID key / cmd BLE custom      ║
 * ╚══════════════════════════════════════════════╝
 */
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ── Limites ─────────────────────────────────── */
#define GESTURE_MAX_COUNT       32
#define GESTURE_MAX_FRAMES      64
#define GESTURE_NAME_LEN        24
#define GESTURE_CMD_LEN         32
#define GESTURE_RING_SIZE       128

/* ── GPIOs dos botões físicos ────────────────── */
#define GESTURE_BTN_GPIO_BACK   2    /* BACK    */
#define GESTURE_BTN_GPIO_FWD    3    /* FORWARD */

/* Bitmask */
#define GESTURE_BTN_NONE  0x00
#define GESTURE_BTN_BACK  (1 << 0)
#define GESTURE_BTN_FWD   (1 << 1)

/* ── Tolerâncias de reconhecimento ──────────── */
#define GESTURE_TOL_ANGLE_DEG   15.0f
#define GESTURE_TOL_FLEX        0.15f
#define GESTURE_DYNAMIC_MIN_PCT 0.75f

/* ════════════════════════════════════════════════
 *  FRAME DE SENSORES
 * ════════════════════════════════════════════════ */
typedef struct {
    float    pitch;           /* MPU6050 — graus              */
    float    roll;            /* MPU6050 — graus              */
    float    flex[2];         /* 0.0 plano … 1.0 dobrado      */
    uint8_t  buttons;         /* GESTURE_BTN_BACK | FWD       */
    uint32_t timestamp_ms;
} gesture_frame_t;

/* ════════════════════════════════════════════════
 *  SAÍDA DO GESTO
 * ════════════════════════════════════════════════ */
typedef enum {
    GESTURE_OUT_HID_MOUSE  = 0,
    GESTURE_OUT_HID_KEY    = 1,
    GESTURE_OUT_CUSTOM_CMD = 2,   /* notificação BLE customizada */
} gesture_out_type_t;

typedef struct { int8_t dx, dy, wheel; uint8_t buttons; } gesture_out_mouse_t;
typedef struct { uint8_t modifier, keycode; }              gesture_out_key_t;

typedef struct {
    gesture_out_type_t type;
    union {
        gesture_out_mouse_t mouse;
        gesture_out_key_t   key;
        char                cmd[GESTURE_CMD_LEN];
    };
} gesture_output_t;

/* ════════════════════════════════════════════════
 *  DEFINIÇÃO DE UM GESTO
 * ════════════════════════════════════════════════ */
typedef enum {
    GESTURE_TYPE_STATIC  = 0,
    GESTURE_TYPE_DYNAMIC = 1,
} gesture_type_t;

typedef struct {
    uint8_t          id;
    char             name[GESTURE_NAME_LEN];
    gesture_type_t   type;
    gesture_output_t output;
    bool             enabled;
    /* estático: 1 frame de referência */
    gesture_frame_t  ref_frame;
    /* dinâmico: sequência de frames */
    uint8_t          frame_count;
    uint32_t         total_duration_ms;
    gesture_frame_t  frames[GESTURE_MAX_FRAMES];
} gesture_def_t;

typedef struct {
    bool    matched;
    uint8_t gesture_id;
    float   confidence;
} gesture_match_t;

typedef void (*gesture_on_match_cb_t)(const gesture_def_t *g, float confidence);

/* ════════════════════════════════════════════════
 *  API
 * ════════════════════════════════════════════════ */
esp_err_t       gesture_engine_init(void);
void            gesture_engine_set_match_cb(gesture_on_match_cb_t cb);

void            gesture_engine_feed(const gesture_frame_t *frame);
gesture_match_t gesture_recognize_static(const gesture_frame_t *frame);
gesture_match_t gesture_recognize_dynamic(void);
uint8_t         gesture_read_buttons(void);

esp_err_t gesture_record_static_begin(const char *name, const gesture_output_t *out);
esp_err_t gesture_record_dynamic_begin(const char *name, const gesture_output_t *out);
esp_err_t gesture_record_dynamic_end(void);
void      gesture_record_cancel(void);
bool      gesture_is_recording(void);

esp_err_t gesture_list(gesture_def_t *list, uint8_t max, uint8_t *count);
esp_err_t gesture_get_by_id(uint8_t id, gesture_def_t *out);
esp_err_t gesture_delete(uint8_t id);
esp_err_t gesture_set_enabled(uint8_t id, bool en);
esp_err_t gesture_save_all_to_nvs(void);
esp_err_t gesture_factory_reset(void);

#ifdef __cplusplus
}
#endif
